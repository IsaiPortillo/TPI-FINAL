<template>
  <div id="about">
    <div class="text">
      <h1>catalogo</h1>
    </div>

    <section class="movies" id="movies">
      <h2 class="heading">Lo mas Reciente</h2>
    </section>
    <DetailMovieComponent :movie="detailMovie" />
    <button v-on:click="irHome()">Ir home</button>
    <div class="container d-block mt-3">
      <div
        class="card d-inline-flex ms-4 mb-4"
        style="width: 18rem; color: black"
        v-for="(item, index) in listMovies"
        :key="index"
      >
        <button id="bot" type="submit" v-on:click="setSpecificMovie(item)">
          <img
            class="card-img-top"
            :src="item.urlImageMovie"
            alt="Card image cap"
          />
        </button>
        <div class="card-footer">
          <small class="text-muted">Likes totales: {{ item.likesMovie }}</small>
          <a
            href="#"
            class="corazon"
            v-if="item.likeUserMovie && user!=null"
            v-on:click.prevent="quitarLike(item.id)"
          >
            <i class="bx bxs-heart text-danger"></i>
          </a>
          <a
            href="#"
            class="corazon"
            v-if="!item.likeUserMovie && user!=null"
            v-on:click.prevent="darLike(item.id)"
          >
            <i class="bx bx-heart bx-flashing text-danger"></i>
          </a>
        </div>
        <div class="card-body">
          <h3 class="card-text">
            {{ item.titleMovie }}
          </h3>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import DetailMovieComponent from "@/components/DetailMovieComponent.vue";
import axios from "axios";
export default {
  components: {
    DetailMovieComponent,
  },
  data() {
    return {
      user:{id:1,idRolUser:2},
      listMovies: [],
      detailMovie: {
        data: null,
        display: false,
      },
    };
  },
  methods: {
    setSpecificMovie(movie) {
      this.detailMovie.data = movie;
      this.detailMovie.display = true;
    },
    async getMoviesFromApi() {
      axios
        .get("http://127.0.0.1:8000/api/movies/3")
        .then((response) => {
          if (response.status == 200) {
            this.listMovies = response.data;
          }
        })
        .catch((err) => console.log(err));
    },
    async darLike(idMovie) {
      axios
        .post("http://127.0.0.1:8000/api/likes", {
          idUserLike: 3,
          idMovieLike: idMovie,
        })
        .then((response) => {
          console.log(response);
          this.getMoviesFromApi();
        });
    },
    async quitarLike(idMovie) {
      axios
        .delete("http://127.0.0.1:8000/api/likes", {
          data: {
            idUserLike: 3,
            idMovieLike: idMovie,
          },
        })
        .then((response) => {
          console.log(response);
          this.getMoviesFromApi();
        });
    },
    irHome() {
      this.$router.push("/");
    },
  },
  mounted() {
    this.getMoviesFromApi();
  },
};
</script>
<style lang="css">
#about {
  color: white;
}
.text {
  margin-top: 10%;
  margin-bottom: 2%;
}
.text h1 {
  font-size: 70px;
  font-weight: bold;
  text-transform: uppercase;
  border-bottom: 1px solid var(--main-color);
}

.corazon {
  float: right;
  font-size: 20px;
}
.bot {
  border: none;
}
.card {
  width: 100%;
}
.heading {
  max-width: 968px;
  margin-left: auto;
  margin-right: auto;
  font-size: 1.2rem;
  font-weight: 500;
}
</style>
