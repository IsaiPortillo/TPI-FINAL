<template>
    <div class="login">
      <div id="login">
    <h1>Estas en Login</h1>
    </div>
  </div>
</template>
<script>
export default {
    
}
</script>
<style lang="css">
    h1{
      color: white;
    }
  #login{
    margin-top: 20%;
  }
</style>